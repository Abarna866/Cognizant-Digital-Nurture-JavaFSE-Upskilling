import java.util.Scanner;

public class StringReversal {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter String: ");

        String str = sc.nextLine();

        StringBuilder sb =
                new StringBuilder(str);

        System.out.println(
                "Reversed String = "
                + sb.reverse());

        sc.close();
    }
}